The P2F file can be imported in Eclipse using File->Import->Install->Installation items from File.
That way you get all necessary plugins for TV-Browser development.