#!/bin/bash
mono OTRRemote.exe

# Use this line, if you want to see why a mono program crashes without simply closing it
#mono --debug OTRRemote.exe